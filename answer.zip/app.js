var codejam = require("./codejam.js");

codejam.run(function(line){
  
  var array = line.split(" "),
    result;
  
  /**
   * Hack your logic here.
   */
   
  // Exaple:
  result = array.length * array.length;
  
  return result;
});
